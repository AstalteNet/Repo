#version 150

uniform sampler2D DiffuseSampler;
uniform sampler2D DiffuseDepthSampler;
uniform sampler2D ControlSampler;

uniform vec2 OutSize;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

float time() {
    vec3 control_time = texelFetch(ControlSampler, ivec2(0, 0), 0).rgb;
    return control_time.x + 255. * control_time.y + 65025. * control_time.z;
}
float timeStored() {
    vec3 control_time = texelFetch(ControlSampler, ivec2(0, 3), 0).rgb;
    return control_time.x + 255. * control_time.y + 65025. * control_time.z;
}

vec3 rainbowColor(float t) {
    t = mod(t, 1.0);
    float r = abs(t * 6.0 - 3.0) - 1.0;
    float g = 2.0 - abs(t * 6.0 - 2.0);
    float b = 2.0 - abs(t * 6.0 - 4.0);
    return clamp(vec3(r, g, b), 0.0, 1.0);
}

void main() {
    vec4 prev_color  = texture(DiffuseSampler, texCoord);
    vec4 overlay;
	fragColor = prev_color;

    float t = time();

    vec4 control_color = texelFetch(ControlSampler, ivec2(0, 2), 0);
    
    int channel2_code = int(control_color.b * 255.);    

    //particle minecraft:entity_effect ~ ~ ~ 0.9960784313725490196078431372549 0.98823529411764705882352941176471 0.004 1 0 force @s
    if (channel2_code == 1) {
        fragColor.r += 1;
        fragColor.g += 1;
        fragColor.b += 1;
    }


    if(channel2_code == 100){
        vec2 center = vec2(0.5, 0.5); // Center of the screen
        float outerRadius = 0.25; // Outer radius of the hoop
        float innerRadius = 0.20; // Inner radius of the hoop

        // Calculate the distance and angle from the current fragment to the center
        vec2 toCenter = texCoord - center;
        float dist = length(toCenter);
        float angle = atan(toCenter.y, toCenter.x) / (2.0 * 3.14159265) + 0.5;

        // Add rotation based on time
        float rotationSpeed = 1.0; // Adjust this value to change rotation speed
        angle += rotationSpeed * time();

        // Set the fragment color to a rainbow color if it's within the hoop thickness
        if (dist < outerRadius && dist > innerRadius) {
            fragColor = vec4(rainbowColor(angle), 1.0);
        }
    }
}

