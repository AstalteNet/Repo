#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform ConcussConfig {
    float Strength;
};

layout(location = 0) out vec4 fragColor;

void main() {
    float t = GameTime * 1200.0;
    vec2 center = vec2(0.5);
    vec2 toCenter = texCoord - center;
    float dist = length(toCenter);

    vec3 blurred = vec3(0.0);
    const int SAMPLES = 10;
    for (int i = 0; i < SAMPLES; i++) {
        float k = float(i) / float(SAMPLES - 1);
        vec2 uv = center + toCenter * (1.0 - k * 0.08 * Strength * (0.35 + dist));
        blurred += texture(InSampler, uv).rgb;
    }
    blurred /= float(SAMPLES);

    vec2 ghostOffset = vec2(sin(t * 2.3), cos(t * 1.7)) * 0.015 * Strength;
    vec3 ghost = texture(InSampler, texCoord + ghostOffset).rgb;
    vec3 color = mix(blurred, ghost, 0.4 * Strength);

    float gray = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(color, vec3(gray), 0.8 * Strength);

    float haze = smoothstep(0.2, 0.75, dist);
    color = mix(color, vec3(0.92), haze * 0.6 * Strength);

    fragColor = vec4(color, 1.0);
}
