#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform ConcussStateConfig {
    float ResetGap;
};

layout(location = 0) out vec4 fragColor;

const float PERIOD = 1200.0;

float decodeTime(vec2 c) {
    return (floor(c.x * 255.0 + 0.5) + c.y) / 255.0 * PERIOD;
}

vec2 encodeTime(float t) {
    float v = clamp(t / PERIOD, 0.0, 0.99999) * 255.0;
    return vec2(floor(v) / 255.0, fract(v));
}

void main() {
    float now = mod(GameTime * 1200.0, PERIOD);
    vec4 previous = texelFetch(InSampler, ivec2(0, 0), 0);
    float start = decodeTime(previous.rg);
    float last = decodeTime(previous.ba);
    float gap = mod(now - last + PERIOD, PERIOD);
    if (gap > ResetGap || previous == vec4(0.0)) {
        start = now;
    }
    fragColor = vec4(encodeTime(start), encodeTime(now));
}
