#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

uniform sampler2D InSampler;
uniform sampler2D StateSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform ConcussOutConfig {
    float FadeSeconds;
};

layout(location = 0) out vec4 fragColor;

const float PERIOD = 1200.0;

float decodeTime(vec2 c) {
    return (floor(c.x * 255.0 + 0.5) + c.y) / 255.0 * PERIOD;
}

float signedDelta(float a, float b) {
    return mod(a - b + PERIOD * 0.5, PERIOD) - PERIOD * 0.5;
}

void main() {
    float now = mod(GameTime * 1200.0, PERIOD);
    float start = decodeTime(texelFetch(StateSampler, ivec2(0, 0), 0).rg);
    float elapsed = max(signedDelta(now, start), 0.0);
    float s = clamp(1.0 - elapsed / FadeSeconds, 0.0, 1.0);
    float Strength = s * s * (3.0 - 2.0 * s);

    float t = GameTime * 1200.0;
    vec2 center = vec2(0.5);
    vec2 toCenter = texCoord - center;
    float dist = length(toCenter);

    vec3 blurred = vec3(0.0);
    const int SAMPLES = 10;
    for (int i = 0; i < SAMPLES; i++) {
        float k = float(i) / float(SAMPLES - 1);
        vec2 uv = center + toCenter * (1.0 - k * 0.08 * Strength * (0.35 + dist));
        blurred += texture(InSampler, uv).rgb;
    }
    blurred /= float(SAMPLES);

    vec2 ghostOffset = vec2(sin(t * 2.3), cos(t * 1.7)) * 0.015 * Strength;
    vec3 ghost = texture(InSampler, texCoord + ghostOffset).rgb;
    vec3 color = mix(blurred, ghost, 0.4 * Strength);

    float gray = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(color, vec3(gray), 0.8 * Strength);

    float haze = smoothstep(0.2, 0.75, dist);
    color = mix(color, vec3(0.92), haze * 0.6 * Strength);

    fragColor = vec4(color, 1.0);
}
