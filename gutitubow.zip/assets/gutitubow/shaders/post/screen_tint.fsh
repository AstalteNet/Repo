#version 330
#extension GL_ARB_separate_shader_objects : require

// Full-screen tint used by gutitubow:grayscale and gutitubow:flash/NN.
// Desaturate: 0 = original colours, 1 = fully grey.
// Overlay:    rgb colour blended over the screen with strength Overlay.a.

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform TintConfig {
    vec4 Overlay;
    float Desaturate;
};

layout(location = 0) out vec4 fragColor;

void main() {
    vec3 color = texture(InSampler, texCoord).rgb;
    float gray = (color.r + color.g + color.b) / 3.0;
    color = mix(color, vec3(gray), clamp(Desaturate, 0.0, 1.0));
    color = mix(color, Overlay.rgb, clamp(Overlay.a, 0.0, 1.0));
    fragColor = vec4(color, 1.0);
}
