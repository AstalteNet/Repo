#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:globals.glsl>

// Rotating rainbow hoop in the middle of the screen.

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;

layout(std140) uniform RingConfig {
    float OuterRadius;
    float InnerRadius;
    float RotationSpeed; // revolutions per second
};

layout(location = 0) out vec4 fragColor;

vec3 rainbowColor(float t) {
    t = fract(t);
    float r = abs(t * 6.0 - 3.0) - 1.0;
    float g = 2.0 - abs(t * 6.0 - 2.0);
    float b = 2.0 - abs(t * 6.0 - 4.0);
    return clamp(vec3(r, g, b), 0.0, 1.0);
}

void main() {
    fragColor = vec4(texture(InSampler, texCoord).rgb, 1.0);

    vec2 toCenter = texCoord - vec2(0.5);
    float dist = length(toCenter);
    if (dist < OuterRadius && dist > InnerRadius) {
        // GameTime is the fraction of a 24000-tick day; * 1200 gives seconds.
        float seconds = GameTime * 1200.0;
        float angle = atan(toCenter.y, toCenter.x) / 6.28318530718 + 0.5;
        fragColor = vec4(rainbowColor(angle + RotationSpeed * seconds), 1.0);
    }
}
