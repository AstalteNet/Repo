#version 150

uniform sampler2D DiffuseSampler;
uniform vec2 OutSize;

in vec2 texCoord;

out vec4 fragColor;

const int GRID_SIZE = 48;
const float ALPHA_THRESHOLD = 0.01;

void main() {
    vec3 foundColor = vec3(0.0);
    float maxAlpha = 0.0;

    for (int i = 0; i < GRID_SIZE; i++) {
        for (int j = 0; j < GRID_SIZE; j++) {
            // Ensure we sample the entire texture, including edges
            vec2 sampleCoord = vec2(
                float(i) / float(GRID_SIZE - 1),
                float(j) / float(GRID_SIZE - 1)
            );
            
            vec4 sampleColor = texture(DiffuseSampler, sampleCoord);
            
            if (sampleColor.a > maxAlpha) {
                maxAlpha = sampleColor.a;
                foundColor = sampleColor.rgb;
            }

            // Early exit if we've found a fully opaque color
            if (maxAlpha >= 0.25) {
                break;
            }
        }
        if (maxAlpha >= 1.0) {
            break;
        }
    }

    // If no color found above threshold, default to gray
    if (maxAlpha <= ALPHA_THRESHOLD) {
        foundColor = vec3(0.5);
    }

    fragColor = vec4(foundColor, 1.0);
}