#version 150

uniform sampler2D DiffuseSampler;
uniform sampler2D DiffuseDepthSampler;
uniform sampler2D ControlSampler;

uniform vec2 OutSize;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

float BlurRadius = 5.0; // Radius of blur effect

vec4 handleDuplicateVision(float DuplicateVisionStrength){
        // Sample the depth texture
        float depth = texture(DiffuseDepthSampler, texCoord).r;

        // Simulate distortion using simple sine and cosine functions
        vec2 distortion = vec2(sin(texCoord.y * 10.0), cos(texCoord.x * 10.0)) * depth * 0.03;

        // Calculate distorted texture coordinates
        vec2 distortedTexCoord = texCoord + distortion * oneTexel;

        // Calculate offsets for duplicate vision effect based on DuplicateVisionStrength
        vec4 texLeft = texture(DiffuseSampler, distortedTexCoord - vec2(DuplicateVisionStrength, 0.0));
        vec4 texRight = texture(DiffuseSampler, distortedTexCoord + vec2(DuplicateVisionStrength, 0.0));

        // Combine the two samples for a duplicate vision effect
        vec4 finalColor = mix(texLeft, texRight, 0.5);

        // Apply blur effect
        vec4 blurredColor = vec4(0.0);
        float blurSize = BlurRadius * oneTexel.x;

        // Sample neighbors and accumulate
        for (float i = -BlurRadius; i <= BlurRadius; i += 1.0) {
            vec2 offset = vec2(i * blurSize, 0.0);
            blurredColor += texture(DiffuseSampler, distortedTexCoord + offset);
        }

        blurredColor /= (2.0 * BlurRadius + 1.0); // Normalize by number of samples

        // Mix blurred color with final color
        finalColor = mix(finalColor, blurredColor, 0.2); // Adjust blend factor for intensity of blur

        return finalColor;

}

float time() {
    vec3 control_time = texelFetch(ControlSampler, ivec2(0, 0), 0).rgb;
    return control_time.x + 255. * control_time.y + 65025. * control_time.z;
}
float timeStored() {
    vec3 control_time = texelFetch(ControlSampler, ivec2(0, 3), 0).rgb;
    return control_time.x + 255. * control_time.y + 65025. * control_time.z;
}

vec3 rainbowColor(float t) {
    t = mod(t, 1.0);
    float r = abs(t * 6.0 - 3.0) - 1.0;
    float g = 2.0 - abs(t * 6.0 - 2.0);
    float b = 2.0 - abs(t * 6.0 - 4.0);
    return clamp(vec3(r, g, b), 0.0, 1.0);
}

void main() {
    vec4 prev_color  = texture(DiffuseSampler, texCoord);
    vec4 overlay;
	fragColor = prev_color;

    
    // Channel #1
    //vec4 control_color = texelFetch(ControlSampler, ivec2(0, 1), 0);
    //switch(int(control_color.b * 255.)) {
    //    case 1:
    //        fragColor.b += 0.5;
    //        break;
    //}

    float t = time();
    // Channel #2
    vec4 control_color = texelFetch(ControlSampler, ivec2(0, 2), 0);

    int channel2_code = int(control_color.b * 255.);    

    if (channel2_code > 0 && channel2_code <= 10) {
        fragColor = handleDuplicateVision(0.04);
        float increment = float(channel2_code - 1) * 0.125;
        fragColor.r += increment;
        fragColor.g += increment;
        fragColor.b += increment;
    }

    vec3 control_time = texelFetch(ControlSampler, ivec2(0, 3), 0).rgb;
    if(control_time.r != 0 && control_time.g != 0 && control_time.b != 0){
    }

    //fragColor.r += fract(timeStored());


    if(channel2_code == 11){
        float diff = time() - timeStored();
        float increment = 1.5 - (diff * 0.2);
        if(increment > 0){
            fragColor = handleDuplicateVision(min(0.04 , increment * 0.05));
            fragColor.r += increment;
            fragColor.g += increment;
            fragColor.b += increment;
        }
        //0.044
        //fragColor.r *= fract(t / 2);
    }

    if(channel2_code == 12){
        //0.05
    }


    if(channel2_code == 100){
        vec2 center = vec2(0.5, 0.5); // Center of the screen
        float outerRadius = 0.25; // Outer radius of the hoop
        float innerRadius = 0.20; // Inner radius of the hoop

        // Calculate the distance and angle from the current fragment to the center
        vec2 toCenter = texCoord - center;
        float dist = length(toCenter);
        float angle = atan(toCenter.y, toCenter.x) / (2.0 * 3.14159265) + 0.5;

        // Add rotation based on time
        float rotationSpeed = 1.0; // Adjust this value to change rotation speed
        angle += rotationSpeed * time();

        // Set the fragment color to a rainbow color if it's within the hoop thickness
        if (dist < outerRadius && dist > innerRadius) {
            fragColor = vec4(rainbowColor(angle), 1.0);
        }
    }
}

