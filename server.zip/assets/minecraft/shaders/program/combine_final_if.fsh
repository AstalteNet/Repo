#version 150

uniform sampler2D DiffuseSampler;
uniform sampler2D FinalSampler;
uniform sampler2D ColorSampler;

in vec2 texCoord;

out vec4 fragColor;

bool isYellow(vec4 color) {
    vec3 min = vec3(1.0, 1.0, 0.3);
    vec3 max = vec3(1.0, 1.0, 0.4);
    vec3 colorRGB = color.rgb;

    bool result = (colorRGB.r >= min.r && colorRGB.r <= max.r &&
                          colorRGB.g >= min.g && colorRGB.g <= max.g &&
                          colorRGB.b >= min.b && colorRGB.b <= max.b);

    return result;
}

bool isGreen(vec4 color) {
    vec3 min = vec3(0.3, 0.9, 0.3);
    vec3 max = vec3(0.4, 1.0, 0.4);
    vec3 colorRGB = color.rgb;

    bool result = (colorRGB.r >= min.r && colorRGB.r <= max.r &&
                          colorRGB.g >= min.g && colorRGB.g <= max.g &&
                          colorRGB.b >= min.b && colorRGB.b <= max.b);

    return result;
}

bool isBlue(vec4 color) {
    vec3 min = vec3(0.3, 0.3, 0.9);
    vec3 max = vec3(0.4, 0.4, 1.0);
    vec3 colorRGB = color.rgb;

    bool result = (colorRGB.r >= min.r && colorRGB.r <= max.r &&
                          colorRGB.g >= min.g && colorRGB.g <= max.g &&
                          colorRGB.b >= min.b && colorRGB.b <= max.b);

    return result;
}

void main() {
    vec4 diffuseColor = texture(DiffuseSampler, texCoord);


    vec4 tintColor = texture(ColorSampler, texCoord);
    bool tintIsYellow = isYellow(tintColor);

    if(isYellow(tintColor)){
        fragColor = diffuseColor;
        return;
    }
    if(isGreen(tintColor)){
        fragColor = diffuseColor;
        return;
    }
    if(isBlue(tintColor)){
        fragColor = diffuseColor;
        return;
    }
    // Sample colors from both textures
    vec4 finalColor = texture(FinalSampler, texCoord);

    // Overlay finalSampler on top of diffuseSampler using alpha blending
    // Adjust the alpha blending equation based on your desired effect
    vec4 blendedColor = finalColor + diffuseColor * (1.0 - finalColor.a);

    // Output the final blended color
    fragColor = blendedColor;
}