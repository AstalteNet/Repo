#version 150

in vec2 texCoord;
in vec2 oneTexel;

uniform sampler2D DiffuseSampler;
uniform sampler2D DiffuseDepthSampler;
uniform sampler2D ColorSampler;

out vec4 fragColor;

// Adjustable variables
float DuplicateVisionStrength = 0.04; // Strength of duplicate vision effect
float BlurRadius = 5.0; // Radius of blur effect

bool isYellow(vec4 color) {
    vec3 min = vec3(1.0, 1.0, 0.3);
    vec3 max = vec3(1.0, 1.0, 0.4);
    vec3 colorRGB = color.rgb;

    bool result = (colorRGB.r >= min.r && colorRGB.r <= max.r &&
                          colorRGB.g >= min.g && colorRGB.g <= max.g &&
                          colorRGB.b >= min.b && colorRGB.b <= max.b);

    return result;
}

bool isGreen(vec4 color) {
    vec3 min = vec3(0.3, 0.9, 0.3);
    vec3 max = vec3(0.4, 1.0, 0.4);
    vec3 colorRGB = color.rgb;

    bool result = (colorRGB.r >= min.r && colorRGB.r <= max.r &&
                          colorRGB.g >= min.g && colorRGB.g <= max.g &&
                          colorRGB.b >= min.b && colorRGB.b <= max.b);

    return result;
}

bool isBlue(vec4 color) {
    vec3 min = vec3(0.3, 0.3, 0.9);
    vec3 max = vec3(0.4, 0.4, 1.0);
    vec3 colorRGB = color.rgb;

    bool result = (colorRGB.r >= min.r && colorRGB.r <= max.r &&
                          colorRGB.g >= min.g && colorRGB.g <= max.g &&
                          colorRGB.b >= min.b && colorRGB.b <= max.b);

    return result;
}

void main() {
    vec4 tintColor = texture(ColorSampler, texCoord);
    
    if (isYellow(tintColor)) {
        // Sample the depth texture
        float depth = texture(DiffuseDepthSampler, texCoord).r;

        // Simulate distortion using simple sine and cosine functions
        vec2 distortion = vec2(sin(texCoord.y * 10.0), cos(texCoord.x * 10.0)) * depth * 0.03;

        // Calculate distorted texture coordinates
        vec2 distortedTexCoord = texCoord + distortion * oneTexel;

        // Calculate offsets for duplicate vision effect based on DuplicateVisionStrength
        vec4 texLeft = texture(DiffuseSampler, distortedTexCoord - vec2(DuplicateVisionStrength, 0.0));
        vec4 texRight = texture(DiffuseSampler, distortedTexCoord + vec2(DuplicateVisionStrength, 0.0));

        // Combine the two samples for a duplicate vision effect
        vec4 finalColor = mix(texLeft, texRight, 0.5);

        // Apply blur effect
        vec4 blurredColor = vec4(0.0);
        float blurSize = BlurRadius * oneTexel.x;

        // Sample neighbors and accumulate
        for (float i = -BlurRadius; i <= BlurRadius; i += 1.0) {
            vec2 offset = vec2(i * blurSize, 0.0);
            blurredColor += texture(DiffuseSampler, distortedTexCoord + offset);
        }

        blurredColor /= (2.0 * BlurRadius + 1.0); // Normalize by number of samples

        // Mix blurred color with final color
        finalColor = mix(finalColor, blurredColor, 0.2); // Adjust blend factor for intensity of blur

        // Output the final color
        fragColor = finalColor;
    } else if(isGreen(tintColor)){
         // change multiplication factor to adjust "fogginess" - smaller value makes the fog thicker ---------
        float fogginess = 80.0;

        // sample R channel of depth map (grayscale, doesn't matter)
        float depth = 1.0-(1.0-texture(DiffuseDepthSampler, texCoord).r) * fogginess;
    
        // normalize to 0.0-1.0 range
        float ndepth = min(max(depth, 0.0), 1.0);
    
        // crossfade between texture and depthmap with distance
        vec4 tex = texture(DiffuseSampler, texCoord);
        vec4 fog = vec4(0.85, 0.85, 0.95, 1.0);
    
        fragColor = vec4(mix(tex.rgb, fog.rgb, ndepth), tex.a);
    } else if(isBlue(tintColor)){
        // Apply blur effect for blue tinted pixels
        vec4 blurredColor = vec4(0.0);
        float blurSize = BlurRadius * oneTexel.x;

        // Sample neighbors and accumulate
        for (float i = -BlurRadius; i <= BlurRadius; i += 1.0) {
            vec2 offset = vec2(i * blurSize, 0.0);
            blurredColor += texture(DiffuseSampler, texCoord + offset);
        }

        blurredColor /= (2.0 * BlurRadius + 1.0); // Normalize by number of samples

        // Output the blurred color
        fragColor = blurredColor;
    } else {
        // If not yellow, green, or blue, just output the original color
        fragColor = texture(DiffuseSampler, texCoord);
    }
}
